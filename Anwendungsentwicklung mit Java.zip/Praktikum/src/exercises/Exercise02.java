package exercises;

public class Exercise02 {

	public static void main(String[] args) {
		
		String spielername = "Jonas";
		int anzahlVersuche = 0, zufallszahl = 42;
		double durchnittVersuche = 0.54;
		boolean nochmalSpielen = true;
		
		System.out.println("Name: " + spielername);
		System.out.println("Anzahl Versuche: " + anzahlVersuche + " mit der Zufallszahl " + zufallszahl);
		System.out.println("--> " + durchnittVersuche);
		System.out.println("Müchte der Spieler nochmal spielen? " + nochmalSpielen);
		
	}

}
