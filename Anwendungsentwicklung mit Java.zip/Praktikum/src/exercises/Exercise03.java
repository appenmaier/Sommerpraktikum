package exercises;

public class Exercise03 {

	public static void main(String[] args) {

		int anzahlVersuche1 = 5, anzahlVersuche2 = 10;
		int gesamtVersuche = anzahlVersuche1 + anzahlVersuche2;
		int anzahlSpiele = 37;
		double durchschnittlicheVersuche = (double) gesamtVersuche / (double) anzahlSpiele;

		System.out.println("Durchnittliche Versuche 1: " + durchschnittlicheVersuche);
		System.out.println();

		gesamtVersuche += 11;
		anzahlSpiele *= 2;

		durchschnittlicheVersuche = (double) gesamtVersuche / (double) anzahlSpiele;
		System.out.println("Durchnittliche Versuche 2: " + durchschnittlicheVersuche);

	}

}
