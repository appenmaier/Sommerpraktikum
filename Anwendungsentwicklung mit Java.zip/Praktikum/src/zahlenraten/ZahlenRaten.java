package zahlenraten;

import java.util.Random;
import java.util.Scanner;

public class ZahlenRaten {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		boolean loop1 = true;
		System.out.print("Name eingeben: ");
		String name = scanner.next();

		while (loop1) {

			int randomNumber = random.nextInt(99) + 1;
			int guess, counter = 1;
			boolean loop2 = true;

			while (loop2) {

				System.out.print("Zahl eingeben: ");
				guess = scanner.nextInt();

				if (guess < randomNumber) {
					System.out.println("Die gesuchte Zahl ist größer.");
					counter++;
				} else if (guess > randomNumber) {
					System.out.println("Die gesuchte Zahl ist kleiner.");
					counter++;
				} else {
					System.out.println(
							"Glückwunsch " + name + "! Du hast die Zahl beim " + counter + ". Versuch erraten!!");
					loop2 = false;
				}

			}

			System.out.println();
			System.out.println("Möchtest du noch einmal spielen? \n1=Ja \n2=Nein");
			int answer = scanner.nextInt();
			if (answer != 1) {
				loop1 = false;
				System.out.println("Schade, dann bis zum nächsten Mal!");
			}

		}

		scanner.close();

	}

}
