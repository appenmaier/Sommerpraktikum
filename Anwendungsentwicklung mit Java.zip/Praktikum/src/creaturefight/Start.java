package creaturefight;

public class Start {

	public static void main(String[] args) {
		
		Creature creature1 = new Creature("Zombie", 2, 10);
		Creature creature2 = new Creature("Vampir", 4, 6);
		
		creature1.attackCreature(creature2);
		creature2.attackCreature(creature1);
		creature1.attackCreature(creature2);
		creature2.attackCreature(creature1);
		
	}

}
