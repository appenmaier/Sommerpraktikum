package creaturefight;

public class Creature {
	
	private String name;
	private int attackValue, hitPoints;
	
	public Creature(String name, int attackValue, int hitPoints) {
		this.name = name;
		this.attackValue = attackValue;
		this.hitPoints = hitPoints;
	}
	
	public void attackCreature(Creature creature) {
		int hitpoints = creature.getHitpoints();
		hitpoints -= attackValue;
		creature.setHitpoints(hitpoints);
		System.out.println(name + " greift " + creature.getName() + " an und erzielt " + attackValue + " Schaden!");
		System.out.println(creature.getName() + " hat noch " + creature.getHitpoints() + " Lebenspunkte!");
	}
	
	public String getName() {
		return name;
	}
	
	public int getAttackValue() {
		return attackValue;
	}
	
	public int getHitpoints() {
		return hitPoints;
	}
	
	public void setHitpoints(int hitPoints) {
		this.hitPoints = hitPoints;
	}
	
}
