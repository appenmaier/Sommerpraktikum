package zoo;

public class ZooStart {

	public static void main(String[] args) {
		
		Zoo zoo = new Zoo(14.0);
		
		System.out.println("Eintritt: " + zoo.getPrice() + " €.");
		zoo.displayAllAnimals();
		
	}

}
