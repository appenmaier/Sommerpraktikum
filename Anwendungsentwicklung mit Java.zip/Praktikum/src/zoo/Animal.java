package zoo;

public class Animal {
	
	String kind;
	double height;
	int noLegs;
	
	public Animal(String kind, double height, int noLegs) {
		this.kind = kind;
		this.height = height;
		this.noLegs = noLegs;
	}

	public String getKind() {
		return kind;
	}

//	public void setKind(String kind) {
//		this.kind = kind;
//	}

	public double getHeight() {
		return height;
	}

//	public void setHeight(String height) {
//		this.height = height;
//	}

	public int getNoLegs() {
		return noLegs;
	}

//	public void setNoLegs(int noLegs) {
//		this.noLegs = noLegs;
//	}
	
	public void displayAttributes() {
		System.out.println("Art: " + getKind());
		System.out.println("Größe: " + getHeight());
		System.out.println("Anzahl Beine: " + getNoLegs());
	}
	
	
	
}
