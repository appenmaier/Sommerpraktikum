package zoo;

import java.util.ArrayList;

public class Zoo {

	double price;

	Animal animal1 = new Animal("Tiger", 1.2, 4);
	Animal animal2 = new Animal("Elefant", 3.0, 4);
	Animal animal3 = new Animal("Känguru", 2.0, 2);
	Animal animal4 = new Animal("Giraffe", 5.5, 4);

	ArrayList<Animal> animals = new ArrayList<>();

	public Zoo(double price) {
		this.price = price;
		animals.add(animal1);
		animals.add(animal2);
		animals.add(animal3);
		animals.add(animal4);
	}

	public void displayAllAnimals() {
		for (Animal a : animals) {
			a.displayAttributes();
			System.out.println();
		}
	}

	public double getPrice() {
		return price;
	}

//	public void setPrice(double price) {
//		this.price = price;
//	}

}
