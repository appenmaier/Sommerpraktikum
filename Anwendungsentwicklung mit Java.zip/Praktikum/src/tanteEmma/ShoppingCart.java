package tanteEmma;

import java.util.ArrayList;

public class ShoppingCart {

	// Attribute
	private ArrayList<ShoppingCartItem> items = new ArrayList<>();

	// Methoden
	public void addItem(Product product, int amount) {
		ShoppingCartItem item = new ShoppingCartItem(product, amount);
		items.add(item);
	}

	public ArrayList<ShoppingCartItem> getItems() {
		return items;
	}

	public double getTotal() {
		double total = 0;
		for (ShoppingCartItem item : items) {
			total += item.getSubTotal();
		}
		return total;
	}

}
