package tanteEmma;

public class Product {

	// Attribute
	private String description;
	private String classOfGoods;
	private double price;

	// Methoden
	public Product(String description, String classOfGoods, double price) {
		this.description = description;
		this.price = price;
		this.classOfGoods = classOfGoods;
	}

	public String getDescription() {
		return description;
	}

	public String getClassOfGoods() {
		return classOfGoods;
	}

	public double getPrice() {
		return price;
	}

	public void displayProduct() {
		System.out.print(description + " - " + classOfGoods + " - " + price + "\n");
	}

}
