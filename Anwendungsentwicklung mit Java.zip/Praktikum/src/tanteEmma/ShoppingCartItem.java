package tanteEmma;

public class ShoppingCartItem {

	// Attribute
	private Product product;
	private int amount;

	// Methoden
	public ShoppingCartItem(Product goods, int amount) {
		this.product = goods;
		this.amount = amount;
	}

	public Product getProduct() {
		return product;
	}

	public int getAmount() {
		return amount;
	}

	public double getSubTotal() {
		return product.getPrice() * amount;
	}

}