package tanteEmma;

import java.util.ArrayList;
import java.util.Scanner;

public class CornerShop {

	public static void main(String[] args) {

		ArrayList<Product> products = new ArrayList<>();
		products.add(new Product("Butter", "Milchprodukt", 1.49));
		products.add(new Product("Milch", "Milchprodukt", 0.79));
		products.add(new Product("Brot", "Backwaren", 2.49));
		products.add(new Product("Eier", "Tierprodukte", 0.19));

		for (Product p : products) {
			p.displayProduct();
		}

		Scanner scanner = new Scanner(System.in);
		ShoppingCart shoppingCart = new ShoppingCart();

		while (true) {
			System.out.print("Möchten Sie einen weiteren Artikel eingeben (ja, nein)?: ");
			if (!scanner.next().equals("ja")) {
				break;
			}
			System.out.print("Geben Sie bitte den Artikel an: ");
			String description = scanner.next();
			System.out.print("Geben Sie bitte die Menge an: ");
			int amount = scanner.nextInt();
			for (Product p : products) {
				if (p.getDescription().equals(description)) {
					shoppingCart.addItem(p, amount);
				}
			}
		}

		for (ShoppingCartItem item : shoppingCart.getItems()) {
			item.getProduct().displayProduct();
			System.out.println(" - " + item.getAmount() + " - " + item.getSubTotal() + "\n");
		}
		System.out.println(shoppingCart.getTotal());

		scanner.close();

	}

}
