package array;

public class Array_Exercise03 {

	public static void main(String[] args) {

		String[] tiere = { "Hund", "Katze", "Maus", "Pferd" };

		if (tiere[1] == "Katze") {
			tiere[1] = "Pinguin";
		}

		if (tiere[1].equals("Katze") == true) {
			tiere[1] = "Pinguin";
		}

		for (int i = 0; i < tiere.length; i++) {
			System.out.println(tiere[i]);
		}

	}

}
