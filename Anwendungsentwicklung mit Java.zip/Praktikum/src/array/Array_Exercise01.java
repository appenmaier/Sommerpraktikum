package array;

public class Array_Exercise01 {

	public static void main(String[] args) {
		
		int[] array = new int[3];
		
		array[1] = 9;
		
		System.out.println(array.length);
		
		for(int i=0; i<array.length; i++) {
			System.out.println(array[i]);
		}
		
	}

}
