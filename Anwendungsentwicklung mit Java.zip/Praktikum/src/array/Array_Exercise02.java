package array;

public class Array_Exercise02 {

	public static void main(String[] args) {

		int[] array = new int[10];
		int j = 10;

		for (int i = 0; i < array.length; i++) {
			array[i] = j--;
		}

		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
		
		System.out.println();
		System.out.println("Array-Länge: " + array.length);

	}

}
