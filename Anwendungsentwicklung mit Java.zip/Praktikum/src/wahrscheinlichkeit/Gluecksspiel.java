package wahrscheinlichkeit;

import java.util.Random;
import java.util.Scanner;

public class Gluecksspiel {

	public static void main(String[] args) {

		Random random = new Random();

//		while (true) {
			Scanner scanner = new Scanner(System.in);
			int randomNumber = random.nextInt(99) + 1;
	
			System.out.print("Spieler 1, Zahl eingeben: ");
			int guess1 = scanner.nextInt();
			System.out.print("Spieler 2, Zahl eingeben: ");
			int guess2 = scanner.nextInt();
	
			if (Math.abs(guess1 - randomNumber) < Math.abs(guess2 - randomNumber)) {
				System.out.println("Die gesuchte Zahl war die " + randomNumber + ". Spieler 1 gewinnt.");
			} else if (Math.abs(guess1 - randomNumber) > Math.abs(guess2 - randomNumber)) {
				System.out.println("Die gesuchte Zahl war die " + randomNumber + ". Spieler 2 gewinnt.");
			} else {
				System.out.println("Die gesuchte Zahl war die " + randomNumber + ". Unentschieden!.");
			}
			scanner.close();
//		}
	}
}
