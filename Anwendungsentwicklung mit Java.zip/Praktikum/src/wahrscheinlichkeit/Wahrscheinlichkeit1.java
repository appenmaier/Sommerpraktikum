package wahrscheinlichkeit;

public class Wahrscheinlichkeit1 {

	public static void main(String[] args) {

		//for (int i = 0; i < 10; i++) {

			double randomValue = Math.random();
			if (randomValue <= 0.42) {
				System.out.println("Gewonnen");
			} else {
				System.out.println("Verloren");
			}

		//}
	}
}
