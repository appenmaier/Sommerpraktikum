package hangman;

import java.util.ArrayList;
import java.util.Scanner;

public class Hangman {

	public static void main(String[] args) {

		String[] letterPool = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q",
				"R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

		ArrayList<String> arrayList = new ArrayList<>();
		Scanner scanner = new Scanner(System.in);

		int lives = 11;
		boolean loop = true;

		while (loop) {

			boolean check = false, check2 = true;
			System.out.print("Das zu erratende Wort eingeben: ");
			String secret = scanner.next().toUpperCase();
			System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

			for (int i = 0; i < secret.length(); i++) {
				arrayList.add("_ ");
			}
			for (int i = 0; i < arrayList.size(); i++) {
				System.out.print(arrayList.get(i));
			}
			System.out.println();

			while (lives > 0 && check2 == true) {
				System.out.print("Buchstabe eingeben: ");
				String guess = scanner.next().toUpperCase();

				for (int i = 0; i < secret.length(); i++) {
					if (String.valueOf(secret.charAt(i)).equals(guess)) {
						arrayList.set(i, (guess + " "));
						check = true;
					}
				}

				if (check == false) {
					lives--;
				}

				for (int i = 0; i < arrayList.size(); i++) {
					System.out.print(arrayList.get(i));
				}
				System.out.println("Leben: " + lives);
				System.out.println();

				/*
				 * for (int i = 0; i < secret.length(); i++) { if
				 * (String.valueOf(secret.charAt(i)).equals("_ ")) { check2 = true; } else {
				 * check2 = false; } }
				 */
			}

			System.out.println("Du hast verloren. Das zu erratende Wort wäre " + secret + " gewesen.");

		}

	}

}
