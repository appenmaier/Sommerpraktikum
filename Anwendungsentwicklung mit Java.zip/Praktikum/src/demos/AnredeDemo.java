package demos;

public class AnredeDemo {

	public static void main(String[] args) {
		
		String name = "Appenmaier", surname = "Daniel";
		char gender = 'm';
		int age = 36;
		
		if(age >= 18) {
			if(gender == 'm') {
				System.out.println("Hallo Herr " + name +".");
			} else if(gender == 'w') {
				System.out.println("Hallo Frau " + name +".");
			}
		} else {
			System.out.println("Hallo " + surname + ".");
		}
		
	}

}
