package demos;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Gebe deinen Namen ein: ");
		scanner.next();
		
	}

}
