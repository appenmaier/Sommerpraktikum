package demos;

public class Primzahlen {

	public static void main(String[] args) {

		// Deklaration und Initialisierung von Feldern
		String[] names = new String[3];
		int[] numbers = { 4, 7, 1, 2, 9, 3, 5, 6, 8 };

		// Zugriff auf Feld-Elemente
		names[0] = "Hans";
		names[1] = "Lisa";
		names[2] = "Peter";

		System.out.println("numbers[4]: " + numbers[4]);
		System.out.println("numbers[7]: " + numbers[7]);
		System.out.println("numbers[1]: " + numbers[1]);

		// Ausgabe von Feldern
		System.out.println("numbers: " + numbers);

		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			System.out.println("i: " + i + ", name: " + name);
		}

		for (int number : numbers) {
			System.out.println("number: " + number);
		}

	}

}
